/*
 * Floppy//144 - Stage 2E.6 Site room topology
 *
 * Projection-neutral room classification and exact doorway topology for the
 * authoritative 100 x 100 Site.
 *
 * IMPORTANT:
 *   - floppy144_room.h owns the canonical eleven room IDs.
 *   - floppy144_site_layout.def remains the sole physical geometry source.
 *   - No current_room value is persisted.
 *   - The player's canonical Site position determines the current room.
 *   - Door rectangles here exactly match the physical rectangles already
 *     present in floppy144_site_layout.def.
 */

#pragma once

#include "floppy144_room.h"
#include "floppy144_site.h"

#include <stdbool.h>
#include <stdint.h>

/*
 * Canonical rectangular Site region.
 *
 * Coordinates are Office Dimensions coordinates, before the clockwise
 * presentation transform.
 */
typedef struct Floppy144SiteRegion
{
    uint8_t x;
    uint8_t y;
    uint8_t width;
    uint8_t height;
}
Floppy144SiteRegion;

/*
 * A room may use one or more regions.
 *
 * Records Office and Corridor are non-rectangular and therefore use two.
 */
typedef struct Floppy144SiteRoomDefinition
{
    uint8_t first_region;
    uint8_t region_count;
}
Floppy144SiteRoomDefinition;

/*
 * Stable semantic IDs for the thirteen physical door rectangles.
 *
 * These IDs are independent of floppy144_site_layout.def ordering.
 */
typedef enum Floppy144SiteDoorId
{
    FLOPPY144_SITE_DOOR_SITE_ENTRANCE = 0,

    FLOPPY144_SITE_DOOR_RECEPTION_CORRIDOR,
    FLOPPY144_SITE_DOOR_RECEPTION_MAIN_OFFICE,
    FLOPPY144_SITE_DOOR_MAIN_OFFICE_CORRIDOR,
    FLOPPY144_SITE_DOOR_RECORDS_CORRIDOR,

    FLOPPY144_SITE_DOOR_SECRETARY_CORRIDOR,
    FLOPPY144_SITE_DOOR_SECRETARY_DIRECTOR,

    FLOPPY144_SITE_DOOR_SECURITY_CORRIDOR,
    FLOPPY144_SITE_DOOR_IT_SUPPORT_CORRIDOR,
    FLOPPY144_SITE_DOOR_STAFF_ROOM_CORRIDOR,
    FLOPPY144_SITE_DOOR_FACILITIES_CORRIDOR,

    FLOPPY144_SITE_DOOR_IT_SUPPORT_SERVER_ROOM,

    /*
     * Internal Server Room partition.
     *
     * Both sides belong to FLOPPY144_ROOM_SERVER_ROOM, so crossing this
     * doorway does not change room.
     */
    FLOPPY144_SITE_DOOR_SERVER_PROTECTED_AREA,

    FLOPPY144_SITE_DOOR_COUNT
}
Floppy144SiteDoorId;

#define FLOPPY144_SITE_DOOR_OUTSIDE 0xffU

/*
 * Exact physical doorway plus the rooms on either side.
 *
 * room_a / room_b contain Floppy144RoomId values.
 * FLOPPY144_SITE_DOOR_OUTSIDE represents the exterior of the building.
 */
typedef struct Floppy144SiteDoorDefinition
{
    Floppy144SiteRegion rect;

    uint8_t room_a;
    uint8_t room_b;
}
Floppy144SiteDoorDefinition;

/*
 * Room geometry.
 */
const Floppy144SiteRoomDefinition *Floppy144SiteRoomGet(
    Floppy144RoomId room
);

const Floppy144SiteRegion *Floppy144SiteRoomRegionGet(
    uint8_t region_index
);

uint8_t Floppy144SiteRoomRegionCount(
    void
);

bool Floppy144SiteRoomContainsCell(
    Floppy144RoomId room,
    uint8_t x,
    uint8_t y
);

Floppy144RoomId Floppy144SiteRoomAtCell(
    uint8_t x,
    uint8_t y
);

/*
 * Resolve directly from RunState-style 1/16-unit Site coordinates.
 *
 * FLOPPY144_ROOM_COUNT is returned when the position is outside the Site.
 */
Floppy144RoomId Floppy144SiteRoomAtPosition(
    int32_t x16,
    int32_t y16
);

/*
 * Return the overall canonical bounding rectangle for a room.
 *
 * For non-rectangular rooms this is the bounding box around all of its
 * component regions. Membership still uses the exact individual regions.
 */
bool Floppy144SiteRoomBounds(
    Floppy144RoomId room,
    Floppy144SiteRegion *bounds
);

/*
 * Test whether an authoritative Site rectangle overlaps any region belonging
 * to a room.
 *
 * The physical rectangle remains owned by floppy144_site_layout.def. This is
 * purely a visibility query for room-based projections.
 */
bool Floppy144SiteRoomIntersectsRect(
    Floppy144RoomId room,
    uint8_t rect_x,
    uint8_t rect_y,
    uint8_t rect_width,
    uint8_t rect_height
);

/*
 * Exact physical doors.
 */
uint8_t Floppy144SiteDoorCount(
    void
);

const Floppy144SiteDoorDefinition *Floppy144SiteDoorGet(
    Floppy144SiteDoorId door
);

Floppy144SiteDoorId Floppy144SiteDoorAtCell(
    uint8_t x,
    uint8_t y
);

/*
 * Given one side of a door, return the other side.
 *
 * Result is either:
 *   0 .. FLOPPY144_ROOM_COUNT - 1
 *   FLOPPY144_SITE_DOOR_OUTSIDE
 *
 * If the supplied room is not connected to the door, OUTSIDE is returned.
 */
uint8_t Floppy144SiteDoorOtherSide(
    const Floppy144SiteDoorDefinition *door,
    Floppy144RoomId room
);
