/*
 * Floppy//144 - flat 2D Site projection implementation
 *
 * The exact Site remains in projection-neutral Site coordinates.
 * This module translates those coordinates onto the 640 x 360
 * software-rendered canvas.
 *
 * FM-23 can later replace this projection without changing world
 * geometry, collision or the player's RunState position.
 */

#include "floppy144_site_2d.h"

#include "floppy144_draw.h"
#include "floppy144_site.h"
#include "floppy144_site_rooms.h"
#include "floppy144_site_view.h"

#include "floppy144_object_registry.h"
#include "floppy144_site_object.h"

#include <stddef.h>
#include <stdint.h>

/*
 * Flat-plan projection
 *
 * 3 pixels per Site unit gives a 300 x 300 Site representation.
 */

/*
 * Room-view viewport.
 *
 * The header remains above this area and the contextual footer remains below.
 */
#define FLOPPY144_SITE_2D_VIEW_X             16
#define FLOPPY144_SITE_2D_VIEW_Y             26
#define FLOPPY144_SITE_2D_VIEW_WIDTH        608
#define FLOPPY144_SITE_2D_VIEW_HEIGHT       296

/*
 * Comfortable room-view scale.
 *
 * Small rooms may expand as far as 10 pixels/unit.
 * Large rooms never shrink below 7 pixels/unit; instead the camera follows
 * the player and clamps to the room.
 */
#define FLOPPY144_SITE_2D_MIN_SCALE            7
#define FLOPPY144_SITE_2D_MAX_SCALE           10

typedef struct Floppy144SiteStyle2D
{
    uint8_t draw_outline;
    uint32_t colour;
}
Floppy144SiteStyle2D;

typedef struct Floppy144SiteCamera2D
{
    int32_t camera_x16;
    int32_t camera_y16;

    uint8_t pixels_per_unit;
}
Floppy144SiteCamera2D;

/*
 * Restrained GDR translation of the spreadsheet working colours.
 */

static const Floppy144SiteStyle2D
floppy144_site_styles[
    FLOPPY144_SITE_ELEMENT_COUNT
] =
{
    { 0U, FLOPPY144_RGB(61,  67,  65) },
    { 0U, FLOPPY144_RGB(67,  71,  67) },
    { 0U, FLOPPY144_RGB(56,  64,  65) },
    { 0U, FLOPPY144_RGB(73,  74,  67) },

    { 1U, FLOPPY144_RGB(184, 133,  67) },
    { 1U, FLOPPY144_RGB(100, 151, 166) },
    { 1U, FLOPPY144_RGB(111, 108,  97) },
    { 1U, FLOPPY144_RGB(75,   78,  74) },
    { 1U, FLOPPY144_RGB(96,   99,  94) },
    { 1U, FLOPPY144_RGB(73,   77,  75) },
    { 1U, FLOPPY144_RGB(52,   57,  57) },
    { 1U, FLOPPY144_RGB(152, 159, 155) },
    { 1U, FLOPPY144_RGB(93,   83,  67) },
    { 1U, FLOPPY144_RGB(67,   91, 104) },
    { 1U, FLOPPY144_RGB(134, 132, 120) },
    { 1U, FLOPPY144_RGB(137, 140, 132) },
    { 1U, FLOPPY144_RGB(116, 112, 101) },
    { 1U, FLOPPY144_RGB(103, 118, 116) },
    { 1U, FLOPPY144_RGB(75,   67,  58) },
    { 1U, FLOPPY144_RGB(103,  84,  84) },
    { 1U, FLOPPY144_RGB(54,   68,  77) },
    { 1U, FLOPPY144_RGB(84,   80,  68) },
    { 1U, FLOPPY144_RGB(98,   91,  81) },
    { 1U, FLOPPY144_RGB(120, 105,  85) }
};

static bool Floppy144Site2DIsFloor(
    Floppy144SiteElement element
)
{
    return
    element >= FLOPPY144_SITE_FLOOR_A &&
    element <= FLOPPY144_SITE_FLOOR_D;
}

/*
 * Determine whether one authoritative Site rectangle belongs in the current
 * room view.
 *
 * Normal geometry is visible when it physically overlaps the room.
 *
 * Doors receive one additional check because an exact doorway rectangle can
 * sit on only one side of a half-open room boundary while still being visible
 * from both connected rooms.
 */
static bool Floppy144Site2DRectVisibleInRoom(
    Floppy144RoomId room,
    const Floppy144SiteRect *rect
)
{
    uint32_t door_index;

    if(rect == NULL)
    {
        return false;
    }

    if(
        Floppy144SiteRoomIntersectsRect(
            room,
            rect->x,
            rect->y,
            rect->width,
            rect->height
        )
    )
    {
        return true;
    }

    if(
        rect->type !=
        (uint8_t)FLOPPY144_SITE_DOOR
    )
    {
        return false;
    }

    for(
        door_index = 0U;
    door_index <
    (uint32_t)Floppy144SiteDoorCount();
    ++door_index
    )
    {
        const Floppy144SiteDoorDefinition *door =
        Floppy144SiteDoorGet(
            (Floppy144SiteDoorId)door_index
        );

        if(door == NULL)
        {
            continue;
        }

        if(
            door->rect.x != rect->x ||
            door->rect.y != rect->y ||
            door->rect.width != rect->width ||
            door->rect.height != rect->height
        )
        {
            continue;
        }

        if(
            door->room_a == (uint8_t)room ||
            door->room_b == (uint8_t)room
        )
        {
            return true;
        }
    }

    return false;
}

static int32_t Floppy144Site2DClamp(
    int32_t value,
    int32_t minimum,
    int32_t maximum
)
{
    if(value < minimum)
    {
        return minimum;
    }

    if(value > maximum)
    {
        return maximum;
    }

    return value;
}

static bool Floppy144Site2DBuildCamera(
    Floppy144RoomId room,
    const Floppy144RunState *run_state,
    Floppy144SiteCamera2D *camera
)
{
    Floppy144SiteRegion world_bounds;
    Floppy144SiteRect world_rect;
    Floppy144SiteRect view_rect;

    int32_t player_view_x16;
    int32_t player_view_y16;

    int32_t room_x0;
    int32_t room_y0;
    int32_t room_x1;
    int32_t room_y1;

    int32_t room_width;
    int32_t room_height;

    int32_t scale_x;
    int32_t scale_y;
    int32_t scale;

    int32_t visible_width16;
    int32_t visible_height16;

    int32_t room_width16;
    int32_t room_height16;

    int32_t camera_min;
    int32_t camera_max;

    if(
        run_state == NULL ||
        camera == NULL ||
        !Floppy144SiteRoomBounds(
            room,
            &world_bounds
        )
    )
    {
        return false;
    }

    /*
     * Rotate the canonical room bounds using exactly the same presentation
     * transform as every physical Site rectangle.
     */
    world_rect.type =
    (uint8_t)FLOPPY144_SITE_FLOOR_A;

    world_rect.x =
    world_bounds.x;

    world_rect.y =
    world_bounds.y;

    world_rect.width =
    world_bounds.width;

    world_rect.height =
    world_bounds.height;

    Floppy144SiteViewRect(
        &world_rect,
        &view_rect
    );

    room_x0 =
    (int32_t)view_rect.x;

    room_y0 =
    (int32_t)view_rect.y;

    room_x1 =
    room_x0 +
    (int32_t)view_rect.width;

    room_y1 =
    room_y0 +
    (int32_t)view_rect.height;

    room_width =
    (int32_t)view_rect.width;

    room_height =
    (int32_t)view_rect.height;

    if(
        room_width <= 0 ||
        room_height <= 0
    )
    {
        return false;
    }

    /*
     * Find the scale which would fit the entire room.
     *
     * Large rooms stop shrinking at the comfortable minimum scale and use
     * camera movement instead. Small rooms are capped so desks do not become
     * monumental architecture.
     */
    scale_x =
    FLOPPY144_SITE_2D_VIEW_WIDTH /
    room_width;

    scale_y =
    FLOPPY144_SITE_2D_VIEW_HEIGHT /
    room_height;

    scale =
    scale_x < scale_y
    ? scale_x
    : scale_y;

    if(scale < FLOPPY144_SITE_2D_MIN_SCALE)
    {
        scale =
        FLOPPY144_SITE_2D_MIN_SCALE;
    }

    if(scale > FLOPPY144_SITE_2D_MAX_SCALE)
    {
        scale =
        FLOPPY144_SITE_2D_MAX_SCALE;
    }

    camera->pixels_per_unit =
    (uint8_t)scale;

    visible_width16 =
    (
        FLOPPY144_SITE_2D_VIEW_WIDTH *
        FLOPPY144_SITE_FIXED_ONE
    ) /
    scale;

    visible_height16 =
    (
        FLOPPY144_SITE_2D_VIEW_HEIGHT *
        FLOPPY144_SITE_FIXED_ONE
    ) /
    scale;

    room_width16 =
    room_width *
    FLOPPY144_SITE_FIXED_ONE;

    room_height16 =
    room_height *
    FLOPPY144_SITE_FIXED_ONE;

    Floppy144SiteViewPoint(
        run_state->player_site_x,
        run_state->player_site_y,
        &player_view_x16,
        &player_view_y16
    );

    /*
     * Horizontal camera.
     *
     * If the room fits inside the viewport, centre the whole room.
     * Otherwise follow the player and clamp to the room bounds.
     */
    if(room_width16 <= visible_width16)
    {
        camera->camera_x16 =
        room_x0 *
        FLOPPY144_SITE_FIXED_ONE -
        (
            visible_width16 -
            room_width16
        ) / 2;
    }
    else
    {
        camera_min =
        room_x0 *
        FLOPPY144_SITE_FIXED_ONE;

        camera_max =
        room_x1 *
        FLOPPY144_SITE_FIXED_ONE -
        visible_width16;

        camera->camera_x16 =
        Floppy144Site2DClamp(
            player_view_x16 -
            visible_width16 / 2,
            camera_min,
            camera_max
        );
    }

    /*
     * Vertical camera.
     */
    if(room_height16 <= visible_height16)
    {
        camera->camera_y16 =
        room_y0 *
        FLOPPY144_SITE_FIXED_ONE -
        (
            visible_height16 -
            room_height16
        ) / 2;
    }
    else
    {
        camera_min =
        room_y0 *
        FLOPPY144_SITE_FIXED_ONE;

        camera_max =
        room_y1 *
        FLOPPY144_SITE_FIXED_ONE -
        visible_height16;

        camera->camera_y16 =
        Floppy144Site2DClamp(
            player_view_y16 -
            visible_height16 / 2,
            camera_min,
            camera_max
        );
    }

    return true;
}

static int32_t Floppy144Site2DProjectX16(
    const Floppy144SiteCamera2D *camera,
    int32_t world_x16,
    int32_t world_y16
)
{
    int32_t view_x16;

    if(camera == NULL)
    {
        return 0;
    }

    Floppy144SiteViewPoint(
        world_x16,
        world_y16,
        &view_x16,
        NULL
    );

    return
    FLOPPY144_SITE_2D_VIEW_X +
    (
        (
            view_x16 -
            camera->camera_x16
        ) *
        (int32_t)camera->pixels_per_unit
    ) /
    FLOPPY144_SITE_FIXED_ONE;
}

static int32_t Floppy144Site2DProjectY16(
    const Floppy144SiteCamera2D *camera,
    int32_t world_x16,
    int32_t world_y16
)
{
    int32_t view_y16;

    if(camera == NULL)
    {
        return 0;
    }

    Floppy144SiteViewPoint(
        world_x16,
        world_y16,
        NULL,
        &view_y16
    );

    return
    FLOPPY144_SITE_2D_VIEW_Y +
    (
        (
            view_y16 -
            camera->camera_y16
        ) *
        (int32_t)camera->pixels_per_unit
    ) /
    FLOPPY144_SITE_FIXED_ONE;
}

static void Floppy144Site2DDrawSiteRect(
    Floppy144Surface *surface,
    const Floppy144SiteCamera2D *camera,
    const Floppy144SiteRect *rect,
    uint32_t edge_colour
)
{
    Floppy144SiteRect view_rect;

    Floppy144SiteElement element;
    const Floppy144SiteStyle2D *style;

    uint32_t x;
    uint32_t y;
    uint32_t width;
    uint32_t height;

    if(
        surface == NULL ||
        camera == NULL ||
        rect == NULL ||
        rect->type >=
        (uint8_t)FLOPPY144_SITE_ELEMENT_COUNT
    )
    {
        return;
    }

    Floppy144SiteViewRect(
        rect,
        &view_rect
    );

    element =
    (Floppy144SiteElement)view_rect.type;

    style =
    &floppy144_site_styles[element];

    x =
    (uint32_t)Floppy144Site2DProjectX16(
        camera,
        (int32_t)rect->x *
        FLOPPY144_SITE_FIXED_ONE,
        (int32_t)(
            rect->y +
            rect->height
        ) *
        FLOPPY144_SITE_FIXED_ONE
    );

    y =
    (uint32_t)Floppy144Site2DProjectY16(
        camera,
        (int32_t)rect->x *
        FLOPPY144_SITE_FIXED_ONE,
        (int32_t)rect->y *
        FLOPPY144_SITE_FIXED_ONE
    );

    width =
    (uint32_t)view_rect.width *
    (uint32_t)camera->pixels_per_unit;

    height =
    (uint32_t)view_rect.height *
    (uint32_t)camera->pixels_per_unit;

    if(
        width == 0U ||
        height == 0U
    )
    {
        return;
    }

    Floppy144DrawFillRect(
        surface,
        x,
        y,
        width,
        height,
        style->colour
    );

    if(
        style->draw_outline != 0U &&
        width >= 2U &&
        height >= 2U
    )
    {
        Floppy144DrawRect(
            surface,
            x,
            y,
            width,
            height,
            edge_colour
        );
    }
}

/*
 * Draw the player from RunState coordinates.
 *
 * The collision footprint is 3.5 x 3.5 Site units.
 * The visible standing figure is 3.5 units wide and 8 units high.
 *
 * The 8-unit physical height is retained for the future isometric
 * projection, where 8 / 12 gives the required two-thirds wall height.
 */

static void Floppy144Site2DDrawPlayer(
    Floppy144Surface *surface,
    const Floppy144SiteCamera2D *camera,
    const Floppy144RunState *run_state
)
{
    const uint32_t body_colour =
    FLOPPY144_RGB(72, 103, 118);

    const uint32_t shirt_light =
    FLOPPY144_RGB(112, 139, 148);

    const uint32_t skin_colour =
    FLOPPY144_RGB(205, 186, 158);

    const uint32_t trouser_colour =
    FLOPPY144_RGB(39, 48, 54);

    const uint32_t edge_colour =
    FLOPPY144_RGB(18, 23, 26);

    const uint32_t shadow_colour =
    FLOPPY144_RGB(31, 35, 34);

    int32_t foot_x;
    int32_t foot_y;

    int32_t sprite_width;
    int32_t sprite_height;

    int32_t sprite_x;
    int32_t sprite_y;

    if(
        surface == NULL ||
        camera == NULL ||
        run_state == NULL
    )
    {
        return;
    }

    foot_x =
    Floppy144Site2DProjectX16(
        camera,
        run_state->player_site_x,
        run_state->player_site_y
    );

    foot_y =
    Floppy144Site2DProjectY16(
        camera,
        run_state->player_site_x,
        run_state->player_site_y
    );

    sprite_width =
    (
        FLOPPY144_SITE_PLAYER_WIDTH_X16 *
        (int32_t)camera->pixels_per_unit +
        FLOPPY144_SITE_FIXED_ONE / 2
    ) /
    FLOPPY144_SITE_FIXED_ONE;

    sprite_height =
    FLOPPY144_SITE_PLAYER_HEIGHT_UNITS *
    (int32_t)camera->pixels_per_unit;

    if(sprite_width < 9)
    {
        sprite_width =
        9;
    }

    sprite_x =
    foot_x -
    sprite_width / 2;

    sprite_y =
    foot_y -
    sprite_height;

    /*
     * Footprint shadow.
     */

    Floppy144DrawFillRect(
        surface,
        (uint32_t)(
            foot_x -
            sprite_width / 2
        ),
        (uint32_t)(
            foot_y -
            2
        ),
        (uint32_t)sprite_width,
                          4U,
                          shadow_colour
    );

    /*
     * Legs.
     */

    Floppy144DrawFillRect(
        surface,
        (uint32_t)(
            sprite_x +
            2
        ),
        (uint32_t)(
            sprite_y +
            sprite_height -
            7
        ),
        3U,
        7U,
        trouser_colour
    );

    Floppy144DrawFillRect(
        surface,
        (uint32_t)(
            sprite_x +
            sprite_width -
            5
        ),
        (uint32_t)(
            sprite_y +
            sprite_height -
            7
        ),
        3U,
        7U,
        trouser_colour
    );

    /*
     * Torso.
     */

    Floppy144DrawFillRect(
        surface,
        (uint32_t)(
            sprite_x +
            1
        ),
        (uint32_t)(
            sprite_y +
            7
        ),
        (uint32_t)(
            sprite_width -
            2
        ),
        (uint32_t)(
            sprite_height -
            13
        ),
        body_colour
    );

    Floppy144DrawRect(
        surface,
        (uint32_t)(
            sprite_x +
            1
        ),
        (uint32_t)(
            sprite_y +
            7
        ),
        (uint32_t)(
            sprite_width -
            2
        ),
        (uint32_t)(
            sprite_height -
            13
        ),
        edge_colour
    );

    /*
     * Head.
     */

    Floppy144DrawFillRect(
        surface,
        (uint32_t)(
            foot_x -
            3
        ),
        (uint32_t)sprite_y,
                          7U,
                          7U,
                          skin_colour
    );

    Floppy144DrawRect(
        surface,
        (uint32_t)(
            foot_x -
            3
        ),
        (uint32_t)sprite_y,
                      7U,
                      7U,
                      edge_colour
    );

    /*
     * Hair and shirt detail.
     */

    Floppy144DrawFillRect(
        surface,
        (uint32_t)(
            foot_x -
            3
        ),
        (uint32_t)sprite_y,
                          7U,
                          2U,
                          trouser_colour
    );

    Floppy144DrawFillRect(
        surface,
        (uint32_t)(
            sprite_x +
            3
        ),
        (uint32_t)(
            sprite_y +
            9
        ),
        2U,
        2U,
        shirt_light
    );
}

static const char *Floppy144Site2DInteractionPrompt(
    const Floppy144RunState *run_state
)
{
    Floppy144ObjectId object;
    const Floppy144ObjectDefinition *definition;
    const Floppy144ObjectInteractionDefinition *interaction;

    const char *prompt =
    "WASD OR ARROWS TO MOVE";

    if(run_state == NULL)
    {
        return prompt;
    }

    object =
    Floppy144SiteInteractionTarget(
        run_state
    );

    definition =
    Floppy144ObjectGet(
        object
    );

    interaction =
    definition != NULL
    ? definition->interaction
    : NULL;

    if(
        interaction == NULL ||
        interaction->prompt == NULL
    )
    {
        return prompt;
    }

    prompt =
    interaction->prompt;

    if(
        interaction->alternate_prompt != NULL &&
        interaction->alternate_prompt_collection !=
        FLOPPY144_COLLECTION_COUNT &&
        Floppy144RunStateCollectionRestored(
            run_state,
            interaction->alternate_prompt_collection
        )
    )
    {
        prompt =
        interaction->alternate_prompt;
    }

    return prompt;
}

void Floppy144Site2DDraw(
    F144Runtime *runtime,
    const Floppy144RunState *run_state,
    const char *notice
)
{
    const uint32_t background =
    FLOPPY144_RGB(12, 17, 21);

    const uint32_t object_edge =
    FLOPPY144_RGB(27, 32, 32);

    const uint32_t text_colour =
    FLOPPY144_RGB(199, 205, 197);

    const uint32_t muted =
    FLOPPY144_RGB(112, 126, 125);

    const uint32_t amber =
    FLOPPY144_RGB(194, 153, 76);

    const uint32_t viewport_edge =
    FLOPPY144_RGB(68, 78, 78);

    Floppy144Surface surface;

    Floppy144RoomId active_room;
    Floppy144SiteCamera2D camera;

    uint32_t index;
    uint32_t rect_count;

    if(
        runtime == NULL ||
        run_state == NULL ||
        runtime->backbuffer.data == NULL
    )
    {
        return;
    }

    surface.pixels =
    (uint32_t *)runtime->backbuffer.data;

    surface.width =
    runtime->backbuffer.width;

    surface.height =
    runtime->backbuffer.height;

    /*
     * Room identity is derived from the canonical persistent player position.
     *
     * current_room is therefore never duplicated into RunState or the save file.
     */
    active_room =
    Floppy144SiteRoomAtPosition(
        run_state->player_site_x,
        run_state->player_site_y
    );

    if(
        !Floppy144Site2DBuildCamera(
            active_room,
            run_state,
            &camera
        )
    )
    {
        return;
    }

    if(
        active_room ==
        FLOPPY144_ROOM_COUNT
    )
    {
        active_room =
        FLOPPY144_ROOM_RECEPTION;
    }

    Floppy144DrawClear(
        &surface,
        background
    );

    Floppy144DrawRect(
        &surface,
        FLOPPY144_SITE_2D_VIEW_X,
        FLOPPY144_SITE_2D_VIEW_Y,
        FLOPPY144_SITE_2D_VIEW_WIDTH,
        FLOPPY144_SITE_2D_VIEW_HEIGHT,
        viewport_edge
    );

    rect_count =
    Floppy144SiteRectCount();

    /*
     * First pass:
     * floor zones and door thresholds.
     */

    for(
        index = 0U;
    index < rect_count;
    ++index
    )
    {
        const Floppy144SiteRect *rect =
        Floppy144SiteRectAt(index);

        Floppy144SiteElement element;

        if(rect == NULL)
        {
            continue;
        }

        if(
            !Floppy144Site2DRectVisibleInRoom(
                active_room,
                rect
            )
        )
        {
            continue;
        }

        element =
        (Floppy144SiteElement)rect->type;

        if(
            Floppy144Site2DIsFloor(element) ||
            element == FLOPPY144_SITE_DOOR
        )
        {
            Floppy144Site2DDrawSiteRect(
                &surface,
                &camera,
                rect,
                object_edge
            );
        }
    }

    /*
     * Second pass:
     * walls, furniture and fixtures.
     */

    for(
        index = 0U;
    index < rect_count;
    ++index
    )
    {
        const Floppy144SiteRect *rect =
        Floppy144SiteRectAt(index);

        Floppy144SiteElement element;

        if(rect == NULL)
        {
            continue;
        }

        if(
            !Floppy144Site2DRectVisibleInRoom(
                active_room,
                rect
            )
        )
        {
            continue;
        }

        element =
        (Floppy144SiteElement)rect->type;

        if(
            Floppy144Site2DIsFloor(element) ||
            element == FLOPPY144_SITE_DOOR
        )
        {
            continue;
        }

        Floppy144Site2DDrawSiteRect(
            &surface,
            &camera,
            rect,
            object_edge
        );
    }

    /*
     * RunState player above the flat plan.
     */

    Floppy144Site2DDrawPlayer(
        &surface,
        &camera,
        run_state
    );

    /*
     * Temporary Site-screen framing.
     *
     * This becomes the normal contextual footer once Site interaction
     * routing is transferred from the old Office implementation.
     */

    Floppy144DrawText(
        &surface,
        10U,
        5U,
        "GDR SITE // 2D RECONSTRUCTION",
        1U,
        muted
    );

    Floppy144DrawText(
        &surface,
        519U,
        5U,
        "100x100",
        1U,
        amber
    );

    if(notice != NULL)
    {
        Floppy144DrawText(
            &surface,
            10U,
            334U,
            notice,
            1U,
            amber
        );
    }

    Floppy144DrawText(
        &surface,
        10U,
        347U,
        Floppy144Site2DInteractionPrompt(
            run_state
        ),
        1U,
        text_colour
    );
}
