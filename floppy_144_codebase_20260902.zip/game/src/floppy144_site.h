/*
 * Floppy//144 - projection-neutral Site model
 *
 * Defines the exact 100 x 100 GDR Site reconstructed from
 * Office Dimensions.xlsx.
 *
 * Geometry and collision live here in Site coordinates.
 * Rendering belongs to projection-specific modules.
 */

#pragma once

#include <stdbool.h>
#include <stdint.h>

/*
 * Site coordinate system
 *
 * One spreadsheet cell = one Site unit.
 * Sixteen fixed-point ticks represent one Site unit so that half-unit
 * movement and the 3.5-unit player footprint require no floating point.
 */

#define FLOPPY144_SITE_SIZE_UNITS              100
#define FLOPPY144_SITE_FIXED_ONE                16

#define FLOPPY144_SITE_WALL_HEIGHT_UNITS        12
#define FLOPPY144_SITE_PLAYER_WIDTH_X16         56
#define FLOPPY144_SITE_PLAYER_HEIGHT_UNITS       8

#define FLOPPY144_SITE_MOVE_STEP_X16             8

/*
 * Spreadsheet element types.
 *
 * The first four values are the four floor-zone fills in the source plan.
 * Remaining values correspond to the workbook legend.
 */

typedef enum Floppy144SiteElement
{
    FLOPPY144_SITE_FLOOR_A = 0,
    FLOPPY144_SITE_FLOOR_B,
    FLOPPY144_SITE_FLOOR_C,
    FLOPPY144_SITE_FLOOR_D,

    FLOPPY144_SITE_DOOR,
    FLOPPY144_SITE_WINDOW,
    FLOPPY144_SITE_STANDARD_DESK,
    FLOPPY144_SITE_CHAIR,
    FLOPPY144_SITE_NONSECURE_CABINET,
    FLOPPY144_SITE_SECURE_CABINET_HALF,
    FLOPPY144_SITE_SECURE_CABINET_FULL,
    FLOPPY144_SITE_WALL_MOUNTED_ITEM,
    FLOPPY144_SITE_BOOKCASE,
    FLOPPY144_SITE_TERMINAL_DESK,
    FLOPPY144_SITE_PARTITION_WALL,
    FLOPPY144_SITE_FRIDGE,
    FLOPPY144_SITE_WORKTOP,
    FLOPPY144_SITE_SINK,
    FLOPPY144_SITE_COFFEE_MAKER,
    FLOPPY144_SITE_SOFA,
    FLOPPY144_SITE_SERVER,
    FLOPPY144_SITE_SHELVING_FULL,
    FLOPPY144_SITE_TROLLEY,
    FLOPPY144_SITE_TABLE,

    FLOPPY144_SITE_ELEMENT_COUNT
}
Floppy144SiteElement;

/*
 * Compact exact-plan rectangle.
 *
 * Coordinates and dimensions are expressed in whole Site units.
 */

typedef struct Floppy144SiteRect
{
    uint8_t type;
    uint8_t x;
    uint8_t y;
    uint8_t width;
    uint8_t height;
}
Floppy144SiteRect;

uint32_t Floppy144SiteRectCount(
    void
);

const Floppy144SiteRect *Floppy144SiteRectAt(
    uint32_t index
);

bool Floppy144SiteElementBlocksMovement(
    Floppy144SiteElement element
);

bool Floppy144SitePositionBlocked(
    int32_t centre_x16,
    int32_t centre_y16
);

void Floppy144SiteSpawnPosition(
    int32_t *x16,
    int32_t *y16
);

bool Floppy144SiteMovePosition(
    int32_t *x16,
    int32_t *y16,
    int32_t delta_x16,
    int32_t delta_y16
);
