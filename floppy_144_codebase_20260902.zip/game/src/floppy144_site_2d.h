/*
 * Floppy//144 - flat 2D Site projection
 *
 * Renders the projection-neutral 100 x 100 Site model onto the
 * 640 x 360 software backbuffer.
 *
 * This module owns no geometry, collision or player state.
 */

#pragma once

#include "f144_runtime.h"

#include "floppy144_run_state.h"

void Floppy144Site2DDraw(
    F144Runtime *runtime,
    const Floppy144RunState *run_state,
    const char *notice
);
