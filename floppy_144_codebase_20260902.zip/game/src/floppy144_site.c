/*
 * Floppy//144 - projection-neutral Site model implementation
 *
 * Exact Site geometry, movement and collision.
 *
 * This module knows nothing about screen pixels, River2D projections,
 * UI state or rendering.
 */

#include "floppy144_site.h"

#include <stddef.h>

/*
 * Exact geometry extracted from Office Dimensions.xlsx.
 *
 * The original 100 x 100 grid contains 10,000 cells. The X-macro file
 * represents the same geometry as 479 rectangles.
 */

static const Floppy144SiteRect floppy144_site_rects[] =
{
    #define SITE_RECT(type, x, y, width, height) \
    {                                        \
        (uint8_t)(type),                     \
        (uint8_t)(x),                        \
        (uint8_t)(y),                        \
        (uint8_t)(width),                    \
        (uint8_t)(height)                    \
    },

    #include "floppy144_site_layout.def"

    #undef SITE_RECT
};

#define FLOPPY144_SITE_RECT_COUNT \
((uint32_t)(                       \
sizeof(floppy144_site_rects) / \
sizeof(floppy144_site_rects[0])\
))

#define FLOPPY144_SITE_MIN_X16 \
0

#define FLOPPY144_SITE_MIN_Y16 \
0

#define FLOPPY144_SITE_MAX_X16 \
(FLOPPY144_SITE_SIZE_UNITS * FLOPPY144_SITE_FIXED_ONE)

#define FLOPPY144_SITE_MAX_Y16 \
(FLOPPY144_SITE_SIZE_UNITS * FLOPPY144_SITE_FIXED_ONE)

uint32_t Floppy144SiteRectCount(
    void
)
{
    return FLOPPY144_SITE_RECT_COUNT;
}

const Floppy144SiteRect *Floppy144SiteRectAt(
    uint32_t index
)
{
    if(index >= FLOPPY144_SITE_RECT_COUNT)
    {
        return NULL;
    }

    return &floppy144_site_rects[index];
}

/*
 * Collision treatment inherited directly from the exact Site prototype.
 *
 * Floor zones and door cells are walkable.
 * Everything else represented by the spreadsheet legend blocks movement.
 */

bool Floppy144SiteElementBlocksMovement(
    Floppy144SiteElement element
)
{
    if(
        (uint32_t)element >=
        (uint32_t)FLOPPY144_SITE_ELEMENT_COUNT
    )
    {
        return true;
    }

    return
    element >
    FLOPPY144_SITE_DOOR;
}

/*
 * Test a player's 3.5 x 3.5 Site-unit footprint against the Site.
 *
 * The supplied coordinates represent the centre of the player's footprint
 * in 1/16-Site-unit fixed-point coordinates.
 */

bool Floppy144SitePositionBlocked(
    int32_t centre_x16,
    int32_t centre_y16
)
{
    const int32_t half_player =
    FLOPPY144_SITE_PLAYER_WIDTH_X16 / 2;

    const int32_t player_x0 =
    centre_x16 - half_player;

    const int32_t player_x1 =
    centre_x16 + half_player;

    const int32_t player_y0 =
    centre_y16 - half_player;

    const int32_t player_y1 =
    centre_y16 + half_player;

    uint32_t index;

    /*
     * Keep the entire player footprint inside the 100 x 100 Site.
     */

    if(
        player_x0 < FLOPPY144_SITE_MIN_X16 ||
        player_y0 < FLOPPY144_SITE_MIN_Y16 ||
        player_x1 > FLOPPY144_SITE_MAX_X16 ||
        player_y1 > FLOPPY144_SITE_MAX_Y16
    )
    {
        return true;
    }

    for(
        index = 0U;
    index < FLOPPY144_SITE_RECT_COUNT;
    ++index
    )
    {
        const Floppy144SiteRect *rect =
        &floppy144_site_rects[index];

        int32_t rect_x0;
        int32_t rect_x1;
        int32_t rect_y0;
        int32_t rect_y1;

        if(
            !Floppy144SiteElementBlocksMovement(
                (Floppy144SiteElement)rect->type
            )
        )
        {
            continue;
        }

        rect_x0 =
        (int32_t)rect->x *
        FLOPPY144_SITE_FIXED_ONE;

        rect_x1 =
        (
            (int32_t)rect->x +
            (int32_t)rect->width
        ) *
        FLOPPY144_SITE_FIXED_ONE;

        rect_y0 =
        (int32_t)rect->y *
        FLOPPY144_SITE_FIXED_ONE;

        rect_y1 =
        (
            (int32_t)rect->y +
            (int32_t)rect->height
        ) *
        FLOPPY144_SITE_FIXED_ONE;

        if(
            player_x1 > rect_x0 &&
            player_x0 < rect_x1 &&
            player_y1 > rect_y0 &&
            player_y0 < rect_y1
        )
        {
            return true;
        }
    }

    return false;
}

/*
 * Spawn immediately inside the principal entrance.
 *
 * The source-plan entrance occupies x=47..53 on the northern edge.
 * 50.5 places the player centrally within that opening.
 */

void Floppy144SiteSpawnPosition(
    int32_t *x16,
    int32_t *y16
)
{
    if(x16 != NULL)
    {
        *x16 =
        50 * FLOPPY144_SITE_FIXED_ONE +
        FLOPPY144_SITE_FIXED_ONE / 2;
    }

    if(y16 != NULL)
    {
        *y16 =
        4 * FLOPPY144_SITE_FIXED_ONE;
    }
}

/*
 * Move through Site coordinates with axis-separated collision.
 *
 * Testing X and Y independently preserves sliding along furniture and walls.
 */

bool Floppy144SiteMovePosition(
    int32_t *x16,
    int32_t *y16,
    int32_t delta_x16,
    int32_t delta_y16
)
{
    int32_t next;
    bool moved =
    false;

    if(
        x16 == NULL ||
        y16 == NULL
    )
    {
        return false;
    }

    next =
    *x16 +
    delta_x16;

    if(
        !Floppy144SitePositionBlocked(
            next,
            *y16
        )
    )
    {
        if(next != *x16)
        {
            *x16 =
            next;

            moved =
            true;
        }
    }

    next =
    *y16 +
    delta_y16;

    if(
        !Floppy144SitePositionBlocked(
            *x16,
            next
        )
    )
    {
        if(next != *y16)
        {
            *y16 =
            next;

            moved =
            true;
        }
    }

    return moved;
}
