/*
 * Floppy//144 - Stage 2E.6 Site room topology
 *
 * Eleven reconstructed rooms occupy the authoritative 100 x 100 Site.
 *
 * Thirteen compact regions tile the complete Site:
 *   - Corridor uses two regions.
 *   - Records Office uses two regions.
 *   - Every other room uses one.
 *
 * Thirteen exact physical doors are registered separately.
 *
 * No Site geometry is duplicated. floppy144_site_layout.def remains the
 * physical source of truth for floors, walls, doors, windows and furniture.
 */

#include "floppy144_site_rooms.h"

#include <stddef.h>

#define FLOPPY144_ARRAY_COUNT(values) \
((uint8_t)(sizeof(values) / sizeof((values)[0])))

/*
 * Canonical Office Dimensions coordinates.
 *
 * Regions use half-open bounds:
 *
 *   [x, x + width)
 *   [y, y + height)
 *
 * Together these thirteen regions classify all 10,000 Site cells exactly
 * once.
 */
static const Floppy144SiteRegion floppy144_site_room_regions[] =
{
    /*  0: Reception */
    { 34U,  0U, 33U, 34U },

    /*  1-2: Corridor */
    { 46U, 34U, 54U, 11U },
    { 46U, 45U, 12U, 40U },

    /*  3: Main Office */
    { 67U,  0U, 33U, 34U },

    /*  4: Facilities */
    { 46U, 85U, 12U, 15U },

    /*  5-6: Records Office */
    {  0U,  0U, 34U, 34U },
    {  0U, 34U, 46U, 11U },

    /*  7: IT Support */
    { 82U, 45U, 18U, 12U },

    /*  8: Staff Room */
    {  0U, 75U, 46U, 25U },

    /*
     * 9: Secretary's Office
     *
     * The separating partition occupies canonical x=30.
     * Secretary space begins immediately east of it.
     */
    { 31U, 45U, 15U, 30U },

    /*
     * 10: Director's Office
     *
     * Includes the x=30 partition/door threshold for deterministic
     * room-at-position resolution.
     */
    {  0U, 45U, 31U, 30U },

    /* 11: Security */
    { 58U, 45U, 24U, 12U },

    /* 12: Server Room */
    { 58U, 57U, 42U, 43U }
};

/*
 * first_region, region_count
 *
 * IMPORTANT:
 * This array follows Floppy144RoomId order from floppy144_rooms.def.
 */
static const Floppy144SiteRoomDefinition
floppy144_site_rooms[FLOPPY144_ROOM_COUNT] =
{
    {  0U, 1U }, /* RECEPTION */
    {  1U, 2U }, /* CORRIDOR */
    {  3U, 1U }, /* MAIN_OFFICE */
    {  4U, 1U }, /* FACILITIES */
    {  5U, 2U }, /* RECORDS_OFFICE */
    {  7U, 1U }, /* IT_SUPPORT */
    {  8U, 1U }, /* STAFF_ROOM */
    {  9U, 1U }, /* SECRETARY_OFFICE */
    { 10U, 1U }, /* DIRECTOR_OFFICE */
    { 11U, 1U }, /* SECURITY */
    { 12U, 1U }  /* SERVER_ROOM */
};

/*
 * Exact physical door topology.
 *
 * Every rectangle below already exists as FLOPPY144_SITE_DOOR in
 * floppy144_site_layout.def.
 */
static const Floppy144SiteDoorDefinition
floppy144_site_doors[FLOPPY144_SITE_DOOR_COUNT] =
{
    /*
     * Principal external entrance.
     * SITE_RECT(FLOPPY144_SITE_DOOR, 47, 0, 7, 1)
     */
    {
        { 47U,  0U, 7U, 1U },
        FLOPPY144_ROOM_RECEPTION,
        FLOPPY144_SITE_DOOR_OUTSIDE
    },

    /*
     * Reception <-> Corridor
     * SITE_RECT(..., 54, 33, 5, 1)
     */
    {
        { 54U, 33U, 5U, 1U },
        FLOPPY144_ROOM_RECEPTION,
        FLOPPY144_ROOM_CORRIDOR
    },

    /*
     * Reception <-> Main Office
     * SITE_RECT(..., 66, 26, 1, 5)
     */
    {
        { 66U, 26U, 1U, 5U },
        FLOPPY144_ROOM_RECEPTION,
        FLOPPY144_ROOM_MAIN_OFFICE
    },

    /*
     * Main Office <-> Corridor
     * SITE_RECT(..., 81, 33, 5, 1)
     */
    {
        { 81U, 33U, 5U, 1U },
        FLOPPY144_ROOM_MAIN_OFFICE,
        FLOPPY144_ROOM_CORRIDOR
    },

    /*
     * Records Office <-> Corridor
     * SITE_RECT(..., 46, 37, 1, 5)
     */
    {
        { 46U, 37U, 1U, 5U },
        FLOPPY144_ROOM_RECORDS_OFFICE,
        FLOPPY144_ROOM_CORRIDOR
    },

    /*
     * Secretary's Office <-> Corridor
     * SITE_RECT(..., 46, 57, 1, 5)
     */
    {
        { 46U, 57U, 1U, 5U },
        FLOPPY144_ROOM_SECRETARY_OFFICE,
        FLOPPY144_ROOM_CORRIDOR
    },

    /*
     * Secretary's Office <-> Director's Office
     * SITE_RECT(..., 30, 48, 1, 5)
     */
    {
        { 30U, 48U, 1U, 5U },
        FLOPPY144_ROOM_SECRETARY_OFFICE,
        FLOPPY144_ROOM_DIRECTOR_OFFICE
    },

    /*
     * Security <-> Corridor
     * SITE_RECT(..., 66, 44, 5, 1)
     */
    {
        { 66U, 44U, 5U, 1U },
        FLOPPY144_ROOM_SECURITY,
        FLOPPY144_ROOM_CORRIDOR
    },

    /*
     * IT Support <-> Corridor
     * SITE_RECT(..., 87, 44, 5, 1)
     */
    {
        { 87U, 44U, 5U, 1U },
        FLOPPY144_ROOM_IT_SUPPORT,
        FLOPPY144_ROOM_CORRIDOR
    },

    /*
     * Staff Room <-> Corridor
     * SITE_RECT(..., 46, 77, 1, 5)
     */
    {
        { 46U, 77U, 1U, 5U },
        FLOPPY144_ROOM_STAFF_ROOM,
        FLOPPY144_ROOM_CORRIDOR
    },

    /*
     * Facilities <-> Corridor
     * SITE_RECT(..., 49, 84, 5, 1)
     */
    {
        { 49U, 84U, 5U, 1U },
        FLOPPY144_ROOM_FACILITIES,
        FLOPPY144_ROOM_CORRIDOR
    },

    /*
     * IT Support <-> Server Room
     * SITE_RECT(..., 87, 56, 5, 1)
     */
    {
        { 87U, 56U, 5U, 1U },
        FLOPPY144_ROOM_IT_SUPPORT,
        FLOPPY144_ROOM_SERVER_ROOM
    },

    /*
     * Internal Server Room protected-area door.
     * SITE_RECT(..., 68, 67, 5, 1)
     *
     * This is a real physical door but not a room-view transition.
     */
    {
        { 68U, 67U, 5U, 1U },
        FLOPPY144_ROOM_SERVER_ROOM,
        FLOPPY144_ROOM_SERVER_ROOM
    }
};

static bool Floppy144SiteRegionContainsCell(
    const Floppy144SiteRegion *region,
    uint8_t x,
    uint8_t y
)
{
    uint16_t max_x;
    uint16_t max_y;

    if(region == NULL)
    {
        return false;
    }

    max_x =
    (uint16_t)region->x +
    (uint16_t)region->width;

    max_y =
    (uint16_t)region->y +
    (uint16_t)region->height;

    return
    (uint16_t)x >= (uint16_t)region->x &&
    (uint16_t)x < max_x &&
    (uint16_t)y >= (uint16_t)region->y &&
    (uint16_t)y < max_y;
}

const Floppy144SiteRoomDefinition *Floppy144SiteRoomGet(
    Floppy144RoomId room
)
{
    if((uint32_t)room >= (uint32_t)FLOPPY144_ROOM_COUNT)
    {
        return NULL;
    }

    return &floppy144_site_rooms[(uint32_t)room];
}

const Floppy144SiteRegion *Floppy144SiteRoomRegionGet(
    uint8_t region_index
)
{
    if(
        region_index >=
        FLOPPY144_ARRAY_COUNT(floppy144_site_room_regions)
    )
    {
        return NULL;
    }

    return &floppy144_site_room_regions[region_index];
}

uint8_t Floppy144SiteRoomRegionCount(
    void
)
{
    return FLOPPY144_ARRAY_COUNT(
        floppy144_site_room_regions
    );
}

bool Floppy144SiteRoomContainsCell(
    Floppy144RoomId room,
    uint8_t x,
    uint8_t y
)
{
    const Floppy144SiteRoomDefinition *definition;
    uint8_t region_offset;

    if(x >= 100U || y >= 100U)
    {
        return false;
    }

    definition =
    Floppy144SiteRoomGet(room);

    if(definition == NULL)
    {
        return false;
    }

    for(
        region_offset = 0U;
    region_offset < definition->region_count;
    ++region_offset
    )
    {
        const Floppy144SiteRegion *region =
        Floppy144SiteRoomRegionGet(
            (uint8_t)(
                definition->first_region +
                region_offset
            )
        );

        if(
            Floppy144SiteRegionContainsCell(
                region,
                x,
                y
            )
        )
        {
            return true;
        }
    }

    return false;
}

Floppy144RoomId Floppy144SiteRoomAtCell(
    uint8_t x,
    uint8_t y
)
{
    uint32_t room;

    if(x >= 100U || y >= 100U)
    {
        return FLOPPY144_ROOM_COUNT;
    }

    for(
        room = 0U;
    room < (uint32_t)FLOPPY144_ROOM_COUNT;
    ++room
    )
    {
        if(
            Floppy144SiteRoomContainsCell(
                (Floppy144RoomId)room,
                                          x,
                                          y
            )
        )
        {
            return (Floppy144RoomId)room;
        }
    }

    return FLOPPY144_ROOM_COUNT;
}

Floppy144RoomId Floppy144SiteRoomAtPosition(
    int32_t x16,
    int32_t y16
)
{
    int32_t max_position =
    FLOPPY144_SITE_SIZE_UNITS *
    FLOPPY144_SITE_FIXED_ONE;

    uint8_t cell_x;
    uint8_t cell_y;

    if(
        x16 < 0 ||
        y16 < 0 ||
        x16 >= max_position ||
        y16 >= max_position
    )
    {
        return FLOPPY144_ROOM_COUNT;
    }

    cell_x =
    (uint8_t)(
        x16 /
        FLOPPY144_SITE_FIXED_ONE
    );

    cell_y =
    (uint8_t)(
        y16 /
        FLOPPY144_SITE_FIXED_ONE
    );

    return
    Floppy144SiteRoomAtCell(
        cell_x,
        cell_y
    );
}

bool Floppy144SiteRoomBounds(
    Floppy144RoomId room,
    Floppy144SiteRegion *bounds
)
{
    const Floppy144SiteRoomDefinition *definition;
    const Floppy144SiteRegion *first;

    uint16_t min_x;
    uint16_t min_y;
    uint16_t max_x;
    uint16_t max_y;

    uint8_t offset;

    if(bounds == NULL)
    {
        return false;
    }

    definition =
    Floppy144SiteRoomGet(room);

    if(
        definition == NULL ||
        definition->region_count == 0U
    )
    {
        return false;
    }

    first =
    Floppy144SiteRoomRegionGet(
        definition->first_region
    );

    if(first == NULL)
    {
        return false;
    }

    min_x =
    first->x;

    min_y =
    first->y;

    max_x =
    (uint16_t)first->x +
    (uint16_t)first->width;

    max_y =
    (uint16_t)first->y +
    (uint16_t)first->height;

    for(
        offset = 1U;
    offset < definition->region_count;
    ++offset
    )
    {
        const Floppy144SiteRegion *region =
        Floppy144SiteRoomRegionGet(
            (uint8_t)(
                definition->first_region +
                offset
            )
        );

        uint16_t region_max_x;
        uint16_t region_max_y;

        if(region == NULL)
        {
            continue;
        }

        region_max_x =
        (uint16_t)region->x +
        (uint16_t)region->width;

        region_max_y =
        (uint16_t)region->y +
        (uint16_t)region->height;

        if(region->x < min_x)
        {
            min_x = region->x;
        }

        if(region->y < min_y)
        {
            min_y = region->y;
        }

        if(region_max_x > max_x)
        {
            max_x = region_max_x;
        }

        if(region_max_y > max_y)
        {
            max_y = region_max_y;
        }
    }

    bounds->x =
    (uint8_t)min_x;

    bounds->y =
    (uint8_t)min_y;

    bounds->width =
    (uint8_t)(max_x - min_x);

    bounds->height =
    (uint8_t)(max_y - min_y);

    return true;
}

bool Floppy144SiteRoomIntersectsRect(
    Floppy144RoomId room,
    uint8_t rect_x,
    uint8_t rect_y,
    uint8_t rect_width,
    uint8_t rect_height
)
{
    const Floppy144SiteRoomDefinition *definition;

    uint16_t rect_x1;
    uint16_t rect_y1;

    uint8_t offset;

    if(
        rect_width == 0U ||
        rect_height == 0U
    )
    {
        return false;
    }

    definition =
    Floppy144SiteRoomGet(room);

    if(definition == NULL)
    {
        return false;
    }

    rect_x1 =
    (uint16_t)rect_x +
    (uint16_t)rect_width;

    rect_y1 =
    (uint16_t)rect_y +
    (uint16_t)rect_height;

    for(
        offset = 0U;
    offset < definition->region_count;
    ++offset
    )
    {
        const Floppy144SiteRegion *region =
        Floppy144SiteRoomRegionGet(
            (uint8_t)(
                definition->first_region +
                offset
            )
        );

        uint16_t region_x1;
        uint16_t region_y1;

        if(region == NULL)
        {
            continue;
        }

        region_x1 =
        (uint16_t)region->x +
        (uint16_t)region->width;

        region_y1 =
        (uint16_t)region->y +
        (uint16_t)region->height;

        if(
            (uint16_t)rect_x < region_x1 &&
            rect_x1 > (uint16_t)region->x &&
            (uint16_t)rect_y < region_y1 &&
            rect_y1 > (uint16_t)region->y
        )
        {
            return true;
        }
    }

    return false;
}

uint8_t Floppy144SiteDoorCount(
    void
)
{
    return
    (uint8_t)FLOPPY144_SITE_DOOR_COUNT;
}

const Floppy144SiteDoorDefinition *Floppy144SiteDoorGet(
    Floppy144SiteDoorId door
)
{
    if(
        (uint32_t)door >=
        (uint32_t)FLOPPY144_SITE_DOOR_COUNT
    )
    {
        return NULL;
    }

    return &floppy144_site_doors[(uint32_t)door];
}

Floppy144SiteDoorId Floppy144SiteDoorAtCell(
    uint8_t x,
    uint8_t y
)
{
    uint32_t door;

    for(
        door = 0U;
    door < (uint32_t)FLOPPY144_SITE_DOOR_COUNT;
    ++door
    )
    {
        if(
            Floppy144SiteRegionContainsCell(
                &floppy144_site_doors[door].rect,
                x,
                y
            )
        )
        {
            return (Floppy144SiteDoorId)door;
        }
    }

    return FLOPPY144_SITE_DOOR_COUNT;
}

uint8_t Floppy144SiteDoorOtherSide(
    const Floppy144SiteDoorDefinition *door,
    Floppy144RoomId room
)
{
    if(door == NULL)
    {
        return FLOPPY144_SITE_DOOR_OUTSIDE;
    }

    if(
        door->room_a ==
        (uint8_t)room
    )
    {
        return door->room_b;
    }

    if(
        door->room_b ==
        (uint8_t)room
    )
    {
        return door->room_a;
    }

    return FLOPPY144_SITE_DOOR_OUTSIDE;
}
